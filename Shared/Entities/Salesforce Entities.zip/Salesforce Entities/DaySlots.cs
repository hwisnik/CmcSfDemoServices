﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Entities.Salesforce_Entities
{
    public class DaySLots
    {
        public DateTime Date { get; set; }
        public List<Slot> Slots { get; set; }
    }
}
