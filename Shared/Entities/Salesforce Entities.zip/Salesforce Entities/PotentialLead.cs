﻿using System;
using System.Collections.Generic;
using System.Text;
using Shared.Entities.Salesforce_Entities.Address_Entities;

namespace Shared.Entities.Salesforce_Entities
{
    public class PotentialLead
    {
        public Guid LeadId { get; set; }
        public double Distance { get; set; }
        public Address Address { get; set; }
    }
}
