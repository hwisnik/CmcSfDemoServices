﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Entities.Salesforce_Entities.SearchCriteria
{
    
    public static class SearchClient
    {
        public static string get_where_from_object(Client client)
        {
            var search_string = string.Empty;
            var count = 0;
            if (client.ClientId != null)
            {
                if (count >= 1)
                {
                    search_string += " and ";
                }
                search_string += " ClientId = " + client.ClientId;
                count++; 
            }

            if (client.CustomerAccountId != null)
            {
                if (count >= 1)
                {
                    search_string += " and ";
                }
                search_string += " CustomerAccountId = " + client.CustomerAccountId;
                count++; 
            }
            

            return search_string; 
        }
    }
}
