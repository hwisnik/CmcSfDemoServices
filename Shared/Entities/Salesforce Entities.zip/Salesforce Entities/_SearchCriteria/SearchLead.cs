﻿using System;
using System.Collections.Generic;
using System.Text;
using Shared.Entities.Salesforce_Entities.Client_Entities;

namespace Shared.Entities.Salesforce_Entities.SearchCriteria
{
    
    public static class SearchLead
    {
        public static string GetWhereFromObject(Lead lead)
        {
            var searchString = string.Empty;
            var count = 0;
            if (lead.LeadId != null)
            {
                if (count >= 1)
                {
                    searchString += " and ";
                }
                searchString += " lead_id = " + lead.LeadId;
                count++; 
            }

            if (lead.AuditType != null)
            {
                if (count >= 1)
                {
                    searchString += " and ";
                }
                searchString += " audit_type = " + lead.AuditType;
                count++; 
            }

            if (lead.ClientId != null)
            {
                if (count >= 1)
                {
                    searchString += " and ";
                }
                searchString += " client_id = " + lead.ClientId;
                count++; 
            }


            if (lead.LeadSource != null)
            {
                if (count >= 1)
                {
                    searchString += " and ";
                }

                searchString += " lead_id = " + lead.LeadSource;
                count++; 
            }

            return searchString; 
        }
    }
}
