﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Shared.Entities.Salesforce_Entities.Client_Entities
{
    
    public class ClientAccount
    {
        [Required]
        public Guid ClientAccountId { get; set; }

        [Required]
        public Guid LeadId { get; set; }

        [Required]
        public int ClientAccountStatusId { get; set; }

    }

    public class ClientAccountMacro
    {
        public ClientAccount _ClientAccount { get; set; }
        public Lead _Lead { get; set;}
        public LkpAccountStatus _AccountStatus { get; set; }
    }
}
