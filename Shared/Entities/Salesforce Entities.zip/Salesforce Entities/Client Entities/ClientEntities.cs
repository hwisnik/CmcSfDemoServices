﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Shared.Entities.Salesforce_Entities.Client_Entities
{
    public class LkpLeadStatus
    {
        [Required]
        public Guid LeadStatusGuid { get; set; }

        [Required]
        public int ClientLeadStatusId { get; set; }

        [MaxLength(500)]
        public string Name { get; set; }

        [Required]
        [MaxLength(50)]
        public string Description { get; set; }

    }


    public class Usage
    {
        [Required]
        public Guid ClientId { get; set; }

        [MaxLength(50)]
        public string AverageUsage { get; set; }

        [MaxLength(50)]
        public string AverageHeatingUsage { get; set; }

    }


    public class LkpPhoneType
    {
        [Required]
        public Guid PhoneTypeId { get; set; }

        [Required]
        [MaxLength(50)]
        public string Name { get; set; }

    }

    public class LkpContactType
    {
        [Required]
        public Guid ContactTypeId { get; set; }
        
        public string Type { get; set; }
    }

    public class Contact_X_Address
    {
        [Required]
        public Guid ContactId { get; set; }

        [Required]
        public Guid AddressId { get; set; }

    }

    public class Email
    {
        [Required]
        public int EmailID { get; set; }

        [Required]
        public Guid ClientID { get; set; }

        [MaxLength(500)]
        public string EmailAddress { get; set; }

    }

    public class PhoneNumber
    {
        [Required]
        public Guid PhoneNumberId { get; set; }

        [Required]
        public Guid ContactId { get; set; }

        [Required]
        [MaxLength(20)]
        public string phoneNumber { get; set; }

        public bool IsVoiceContactAllowed { get; set; }

        public bool IsSmsContactAllowed { get; set; }

        public bool IsPrimaryContact { get; set; }

        public bool IsAutoCallAllowed { get; set; }

        public Guid PhoneTypeId { get; set; }

    }

    public class PhoneNumberMacro
    {
        public PhoneNumber _PhoneNumber { get; set; }
        public LkpPhoneType _LkpPhoneType { get; set; }
    }

    public class PhoneNumberMajor
    {
        public PhoneNumberMacro _PhoneNumberMacro { get;set; }
        public IEnumerable<Client> _Clients { get; set; }
    }
    

    public class LkpAccountStatus
    {
        [Required]
        public int ClientAccountStatusId { get; set; }

        [MaxLength(500)]
        public string Name { get; set; }

    }


}
