﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Shared.Entities.Salesforce_Entities.Address_Entities;
using Shared.Entities.Salesforce_Entities.Customer_Entities;

namespace Shared.Entities.Salesforce_Entities.Client_Entities
{
    [Table("[CMC-SFDC_DEV].[CLIENT].[LEAD]")]
    public class Lead
    {
        [Key]
        public Guid LeadId { get; set; }

        [Required]
        public Guid ClientId { get; set; }

        [Required]
        public int ClientLeadStatusId { get; set; }

        public Guid AuditType { get; set; }

        [MaxLength(50)]
        public string LeadSource { get; set; }

        public Lead()
        {
            LeadId = new Guid();
            ClientId = new Guid();
            ClientLeadStatusId = 1;
            AuditType = new Guid();
            LeadSource = "Testing";
        }
    }

    public class SFLead
    {
        public SFAddress Address { get; set; }
        public string City { get; set; }
        public string Company { get; set; }
        public string Country { get; set; }
        public bool DoNotCall { get; set; }
        public Email Email { get; set; }
        public Email Alternate_Email_1__c { get; set; }
        public Email Alternate_Email_2__c { get; set; }
        public Email Alternate_Email_3__c { get; set; }
        public string Fax { get; set; }

        public bool HasOptedOutOfEmail { get; set; }
        public string CMC_Lead_Guid__c { get; set; }

        public string InformalName { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Salutation { get; set; }
        public string Suffix { get; set; }
        public string Title { get; set; }

        public double Latitude { get; set; }
        public string LeadSource { get; set; }
        public double Longitude { get; set; }
        public string State { get; set; }
        public string Status { get; set; }
        public string Street { get; set; }

        public string MobilePhone { get; set; }
        public SFPhoneNumber Phone { get; set; }
        public SFPhoneNumber Other_Phone_1__c { get; set; }
        public SFPhoneNumber Other_Phone_2__c { get; set; }
        public SFPhoneNumber Other_Phone_3__c { get; set; }
        public string PhoneNumber { get; set; }
        public string Other_PhoneNumber_1__c { get; set; }
        public string Other_PhoneNumber_2__c { get; set; }
        public string Other_PhoneNumber_3__c { get; set; }
        public string PostalCode { get; set; }
        public Guid Program_Id__c { get; set; }
        public Guid Sub_Program_Id__c { get; set; }
        public SFProgram Program { get; set; }
        public SFSubprogram Sub_Program { get; set; }



        public string Utility_Account_Number__c { get; set; }
        public SFAccount Utility_Account { get; set; }

        public SFLead(LeadMacro _leadMacro)
        {
            //Lead Info
            CMC_Lead_Guid__c = _leadMacro._Lead.LeadId.ToString();
            LeadSource = _leadMacro._Lead.LeadSource.ToString();

            //Address Info
            Address = _leadMacro._Client._Account._Premise._Address;
            City = _leadMacro._Client._Account._Premise._Address._Address.City;
            Street = _leadMacro._Client._Account._Premise._Address._Address.StreetAddress1;
            Latitude = _leadMacro._Client._Account._Premise._Address._Address.Latitude;
            Longitude = _leadMacro._Client._Account._Premise._Address._Address.Longitude;
            PostalCode = _leadMacro._Client._Account._Premise._Address._Address.Zip;
            //Add Country to DB - Address
            Country = _leadMacro._Client._Account._Premise._Address._Address.Country;

            // Comes from ERMs..?
            //phone and email controls
            DoNotCall = false;
            HasOptedOutOfEmail = false;

            var count = 0;

            var EmailList = _leadMacro._Client._Contacts.Where(model => model._LkpContactType.Type == "Email").Take(4);
            var PhoneList = _leadMacro._Client._Contacts.Where(model => model._LkpContactType.Type == "Phone").Take(4);
            Fax = _leadMacro._Client._Contacts.Where(model => model._LkpContactType.Type == "Fax").Select(model => model._PhoneNumber._PhoneNumber.phoneNumber).FirstOrDefault();
            MobilePhone = _leadMacro._Client._Contacts.Where(model => model._LkpContactType.Type == "Mobile").Select(model => model._PhoneNumber._PhoneNumber.phoneNumber).FirstOrDefault();

            Email = new Email();
            Alternate_Email_1__c = new Email();
            Alternate_Email_2__c = new Email();
            Alternate_Email_3__c = new Email();

            Phone = new SFPhoneNumber();
            Other_Phone_1__c = new SFPhoneNumber();
            Other_Phone_2__c = new SFPhoneNumber();
            Other_Phone_3__c = new SFPhoneNumber();


            var sfContacts = EmailList as SFContact[] ?? EmailList.ToArray();
            foreach (var email in sfContacts)
            {
                if (count == 0)
                {
                    Email = email._Email;
                }
                else if (count == 1)
                {
                    Alternate_Email_1__c = email._Email;
                }
                else if (count == 2)
                {
                    Alternate_Email_2__c = email._Email;
                }
                else if (count == 3)
                {
                    Alternate_Email_3__c = email._Email;
                }
            }

            count = 0;
            foreach (var phone in PhoneList)
            {
                if (count == 0)
                {
                    Phone = phone._PhoneNumber;
                    PhoneNumber = phone._PhoneNumber._PhoneNumber.phoneNumber;
                }
                else if (count == 1)
                {
                    Other_Phone_1__c = phone._PhoneNumber;
                    Other_PhoneNumber_1__c = phone._PhoneNumber._PhoneNumber.phoneNumber;
                }
                else if (count == 2)
                {
                    Other_Phone_2__c = phone._PhoneNumber;
                    Other_PhoneNumber_2__c = phone._PhoneNumber._PhoneNumber.phoneNumber;
                }
                else if (count == 3)
                {
                    Other_Phone_3__c = phone._PhoneNumber;
                    Other_PhoneNumber_3__c = phone._PhoneNumber._PhoneNumber.phoneNumber;
                }
            }


            //We dont have a way of identifying the person we are talking to...?
            FirstName = _leadMacro._Client._Contacts.FirstOrDefault()?._Contact.FirstName;
            MiddleName = _leadMacro._Client._Contacts.FirstOrDefault()?._Contact.MiddleName;
            LastName = _leadMacro._Client._Contacts.FirstOrDefault()?._Contact.LastName;
            Salutation = _leadMacro._Client._Contacts.FirstOrDefault()?._Contact.Salutation;
            InformalName = _leadMacro._Client._Contacts.FirstOrDefault()?._Contact.InformalName;
            Suffix = _leadMacro._Client._Contacts.FirstOrDefault()?._Contact.Suffix;
            Title = _leadMacro._Client._Contacts.FirstOrDefault()?._Contact.Title.ToString();

            //Program Stuff
            Company = _leadMacro._Client._Account._Program._Program.Name;
            Program_Id__c = _leadMacro._Client._Account._Program._Program.ProgramId;
            Program = _leadMacro._Client._Account._Program;
            Sub_Program_Id__c = _leadMacro._Client._Account._Subprogram._Subprogram.SubProgramId;
            Sub_Program = _leadMacro._Client._Account._Subprogram;
            Utility_Account_Number__c = _leadMacro._Client._Account._Account.BillingAccount;
            Utility_Account = _leadMacro._Client._Account;
        }

    }

    public class LeadMacro
    {
        public Lead _Lead { get; set; }
        public LkpLeadStatus _LkpLeadStatus { get; set; }
        public SFClientAccount _ClientAccount { get; set; }
        public SFClient _Client { get; set; }

        public LeadMacro()
        {
            _Lead = new Lead();
            _LkpLeadStatus = new LkpLeadStatus();
            _ClientAccount = new SFClientAccount();
            _Client = new SFClient();;
        }
    }

    public class SFClientAccount
    {
        public ClientAccount _ClientAccount { get; set; }
        public LkpAccountStatus _LkpAccountStatus { get; set; }

        public SFClientAccount()
        {
            _ClientAccount = new ClientAccount(); 
            _LkpAccountStatus = new LkpAccountStatus();;
        }
    }

    public class SFClient
    {
        public Client _Client { get; set; }
        public IEnumerable<SFContact> _Contacts { get; set; }
        public SFAccount _Account { get; set; }
        public Usage _Usage { get; set; }

        public SFClient()
        {
            _Client=new Client();
            _Contacts = new List<SFContact>();
            _Account = new SFAccount();
            _Usage = new Usage();
        }
    }

    public class SFContact
    {
        public Contact _Contact { get; set; }
        public LkpContactType _LkpContactType { get; set; }
        public Email _Email { get; set; }
        public SFPhoneNumber _PhoneNumber { get; set; }

        public SFContact()
        {
            _Contact =new Contact();
            _LkpContactType = new LkpContactType();
            _Email = new Email();
            _PhoneNumber = new SFPhoneNumber();
        }
    }

    public class SFPhoneNumber
    {
        public PhoneNumber _PhoneNumber { get; set; }
        public LkpPhoneType _LkpPhoneType { get; set; }

        public SFPhoneNumber()
        {
            _PhoneNumber = new PhoneNumber();
            _LkpPhoneType = new LkpPhoneType();
        }
    }

    public class SFAccount
    {
        public Customer_Entities.Account _Account { get; set; }
        public Customer_Entities.LkpAccountType _LkpAccountType { get; set; }

        public SFPremise _Premise { get; set; }
        public SFProgram _Program { get; set; }
        public SFSubprogram _Subprogram { get; set; }

        public SFAccount()
        {
            _Account = new Account();
            _LkpAccountType = new LkpAccountType();
            _Premise=new SFPremise();
            _Program = new SFProgram();
            _Subprogram= new SFSubprogram();
        }
    }

    public class SFProgram
    {
        public Customer_Entities.Program _Program { get; set; }
        public SFContact _Contact { get; set; }

        public SFProgram()
        {
           _Program = new Program();
           _Contact=new SFContact();
        }
    }

    public class SFSubprogram
    {
        public Customer_Entities.Subprogram _Subprogram { get; set; }
        public SFContact _Contact { get; set; }

        public SFSubprogram()
        {
            _Subprogram=new Subprogram();
            _Contact = new SFContact();
        }
    }

    public class SFPremise
    {
        public Address_Entities.Premise _Premise { get; set; }
        public SFAddress _Address { get; set; }

        public SFPremise()
        {
            _Premise = new Premise();
            _Address=new SFAddress();
        }
    }

    public class SFAddress
    {
        public Address_Entities.Address _Address { get; set; }
        public IEnumerable<SFContact_X_Address> _Contacts { get; set; }

        public SFAddress()
        {
            _Address = new Address();
            _Contacts = new List<SFContact_X_Address>();
        }
    }

    public class SFContact_X_Address
    {
        public Contact_X_Address _Contact_X_Address { get; set; }
        public SFContact _Contact { get; set; }

        public SFContact_X_Address()
        {
            _Contact_X_Address = new Contact_X_Address();
            _Contact=new SFContact();
        }
    }

}
