﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Shared.Entities.Salesforce_Entities.Client_Entities
{
    public class Client
    {
        [Required]
        public Guid ClientId { get; set; }

        [Required]
        public Guid CustomerAccountId { get; set; }

    }

    public class ClientMacro
    {
        public Client _Client { get; set; }
        public Customer_Entities.Account _CustomerAccount { get; set; }
        public IEnumerable<Contact> _Contacts { get; set; }
        public IEnumerable<Usage> _Usages { get; set; }
    }
}
