﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Shared.Entities.Salesforce_Entities.Client_Entities
{
    
    public class Contact
    {
        [Required]
        public Guid ContactId { get; set; }

        public Guid ClientId { get; set; }

        [Required]
        public Guid ContactTypeId { get; set; }

        [MaxLength(50)]
        public string FirstName { get; set; }

        [MaxLength(50)]
        public string MiddleName { get; set; }

        [MaxLength(50)]
        public string LastName { get; set; }

        [MaxLength(50)]
        public string InformalName { get; set; }

        [MaxLength(10)]
        public string Salutation { get; set; }

        [MaxLength(50)]
        public string Suffix { get; set; }

        public Guid Title { get; set; }

        [MaxLength(10)]
        public string Age { get; set; }

        public bool IsAnyContactAllowed { get; set; }
    }

    public class ContactMacro
    {
        public Client _Client { get; set; }
        public LkpContactType _LkpContactType { get; set; }
    }

    public class ContactMajor
    {
        public ContactMacro _ContactMacro { get; set; }
        public IEnumerable<PhoneNumber> _PhoneNumbers { get; set; }
        public IEnumerable<Email> _Emails { get;set; }
    }
}
