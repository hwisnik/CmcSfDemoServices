﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Entities.Salesforce_Entities
{
    public class UtilityProgram
    {
        public int ProgramId { get; set; }
        public string Description { get; set; }
        public List<Technician> Technicians { get; set; }
    }
}
