﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Shared.Entities.Salesforce_Entities.Usage_Entities
{
    public class UsageRawPeco {
        [Required]
        public Guid ClientId { get; set;}
 
        public string ReadDate { get; set;}
 
        public double Usage { get; set;}
 
        [MaxLength(1)]
        public string ReadingType { get; set;}
 
        [MaxLength(3)]
        public string Rate { get; set;}
 
        [MaxLength(5)]
        public string RateStatus { get; set;}
 
        public double Revenue { get; set;}
 
        public int NumberOfDays { get; set;}
    }
}
