﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Shared.Entities.Salesforce_Entities
{

    [Table("[CMC-SFDC_DEV].[CLIENT].[Client]")]
    public class Client
    {
        [Key]
        public Guid ClientId { get; set; }
        public Guid CustomerAccountId { get; set; }
    }
}
