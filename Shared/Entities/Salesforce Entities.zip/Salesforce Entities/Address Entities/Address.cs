﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Shared.Entities.Salesforce_Entities.Address_Entities
{
    public class Address
    {
        [Required]
        public Guid AddressId { get; set; }

        [Required]
        public Guid OwnerTypeId { get; set; }

        [Required]
        public Guid AddressTypeId { get; set; }

        [Required]
        [MaxLength(50)]
        public string StreetAddress1 { get; set; }

        [MaxLength(50)]
        public string StreetAddress2 { get; set; }

        [Required]
        [MaxLength(50)]
        public string Country { get; set; }

        [Required]
        [MaxLength(50)]
        public string City { get; set; }

        [Required]
        [MaxLength(50)]
        public string State { get; set; }
        
        [MaxLength(10)]
        public string Zip { get; set; }

        public double Latitude { get; set; }

        public double Longitude { get; set; }

        public string LastServiceDate { get; set; }

    }
}
