﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Shared.Entities.Salesforce_Entities.Address_Entities
{
    public class LkpPremiseType
    {
        [Required]
        public Guid PremiseTypeId { get; set; }

        [Required]
        [MaxLength(50)]
        public string Name { get; set; }

    }

    public class LkpAddressType
    {
        [Required]
        public Guid AddressTypeId { get; set; }

        [MaxLength(50)]
        public string Name { get; set; }

    }

    public class LkpOwnerType
    {
        [Required]
        public Guid OwnerTypeId { get; set; }

        [Required]
        [MaxLength(50)]
        public string Name { get; set; }

    }
    
    public class Premise
    {
        [Required]
        public Guid PremiseId { get; set; }

        public Guid AddressId { get; set; }

        [Required]
        public Guid PremiseTypeId { get; set; }

        [Required]
        public Guid CustomerAccountId { get; set; }

        [MaxLength(50)]
        public string UtilityPremiseId { get; set; }

    }

}
