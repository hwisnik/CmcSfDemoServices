﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Shared.Entities.Salesforce_Entities.Customer_Entities
{
    public class LkpAccountType {
        [Required]
        public Guid AccountTypeId { get; set;}
 
        [Required]
        [MaxLength(50)]
        public string Name { get; set;}
 
    }
 
    public class Program {
        [Required]
        public Guid ProgramId { get; set;}
 
        [MaxLength(50)]
        public string Name { get; set;}
 
        public Guid ContactId { get; set;}
 
    }
 
    
 
    public class Subprogram {
        [Required]
        public Guid SubProgramId { get; set;}
 
        [Required]
        public Guid ProgramId { get; set;}
 
        [MaxLength(50)]
        public string Name { get; set;}
 
        public Guid ContactId { get; set;}
 
    }


}
