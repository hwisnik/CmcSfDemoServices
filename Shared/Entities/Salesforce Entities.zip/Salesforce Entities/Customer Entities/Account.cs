﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Shared.Entities.Salesforce_Entities.Customer_Entities
{
    public class Account {
        [Required]
        public Guid CustomerAccountId { get; set;}
 
        [Required]
        public Guid ProgramId { get; set;}
 
        public Guid SubProgram { get; set;}
 
        [Required]
        [MaxLength(50)]
        public string BillingAccount { get; set;}
 
        [MaxLength(50)]
        public string PecoCustomerId { get; set;}
 
        public Guid AccountTypeId { get; set;}
 
    }

    public class AccountMacro
    {
        public Account _Account { get; set; }
        public Program _Program { get;set; }
        public Subprogram _Subprogram { get;set;}
        public LkpAccountType _LkpAccountType { get;set; }
    }
}
