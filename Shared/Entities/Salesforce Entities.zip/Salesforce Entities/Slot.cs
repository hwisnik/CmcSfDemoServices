﻿using System;
using System.Collections.Generic;
using System.Text;
using Shared.Entities.Salesforce_Entities.Client_Entities;

namespace Shared.Entities.Salesforce_Entities
{
    public class Slot
    {
        public int SlotPosition { get; set; }
        public bool Filled { get; set; }
        public Lead Lead { get; set; }
        public List<PotentialLead> PotentialLeadList { get; set; }
    }
}
